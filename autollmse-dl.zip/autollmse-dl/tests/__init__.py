"""
Test package initialization.
"""